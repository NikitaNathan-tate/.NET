﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CaRental.Models;
using Microsoft.AspNetCore.Mvc;

namespace CaRental.Controllers
{
    public class MovieController : Controller
    {
        public IActionResult Index()
        {

            var movie = GetMovie();
            return View(movie);
        }

        private IEnumerable<Movie> GetMovie()
        {
            return new List<Movie>
            {

                new Movie { Id = 1, Name = "DoLittle" },
                new Movie { Id = 2, Name = "Matrix" }

            };


        }


    }
}
    
