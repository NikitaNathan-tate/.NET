﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CaRental.Models;
using Microsoft.AspNetCore.Mvc;

namespace CaRental.Controllers
{
    public class CustomerController : Controller
    {
        public IActionResult Index()
        {
            var customer = GetCustomer();
            return View(customer);
        }
        private IEnumerable<Customer> GetCustomer()
        {
            return new List<Customer>
            {

                new Customer { Id = 1, Name = "John Smith" },
                new Customer { Id = 2, Name = "Mary Williams" }

            };


        }
    }
}